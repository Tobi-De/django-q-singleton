# django-q-singleton

[![PyPI - Version](https://img.shields.io/pypi/v/django-q-singleton.svg)](https://pypi.org/project/django-q-singleton)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/django-q-singleton.svg)](https://pypi.org/project/django-q-singleton)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install django-q-singleton
```

## License

`django-q-singleton` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
